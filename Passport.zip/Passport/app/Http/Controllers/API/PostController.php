<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Post;
use Carbon\Carbon;
use App\Http\Requests\PostValidation;
class PostController extends Controller
{
    public function AddPost(PostValidation $request)
    {
        $post = new Post();
        $post->user_id = $request->userid;
        $post->description = $request->description;
        if($request->hasFile('picture')){
            $uniqueid=uniqid();
            $original_name=$request->file('picture')->getClientOriginalName();
            $extension=$request->file('picture')->getClientOriginalExtension();
            $name=Carbon::now()->format('Ymd').'_'.$uniqueid.'.'.$extension;
            $imagepath=url('/storage/uploads/files/'.$name);
            $path=$request->file('picture')->storeAs('public/uploads/files/',$name);  
            $post->picture = $imagepath;
        }
        
        $post->save();
        return response()->json(['status'=>1,'message'=>'File Uploaded Successfully']);
    }
}
