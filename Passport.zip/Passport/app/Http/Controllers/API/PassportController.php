<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\{UserRegistration,UserLogin,ResendCode as CodeResend,VerficationCode, CheckEmail,CheckCode,ForgetPassword as PasswordForget,ChangePassword,ProfileUpdate};
use App\User;
use Hash,Mail,Auth;
use App\Mail\{SendCodeEmail,ForgetPassword,ResendCode};

class PassportController extends Controller
{
   
    public function Login(UserLogin $request)
    {
        if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
            $user = Auth::user();
            $successToken = $user->createToken('lianawho')->accessToken;
            return response()->json(['status'=>1,'message'=>'User Logged In Successfully','token'=>$successToken]);
        }else{
             return response()->json(['status'=>0,'message'=>"Invalid Credentials....."]);
        }
    }
    public function Register(UserRegistration $request)
    {
        $code = random_int(100000, 999999);
        $user =  User::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone'=>$request->phone,
            'password' => Hash::make($request->password),
            'is_active'=> 0,
            'token'=>$code,
        ]);
        Mail::to($user)->send(new SendCodeEmail);
        $success['token'] = $user->createToken('lianawho')->accessToken;
        return response()->json(['status'=>1,'message'=>'User Registered. Activation Code Sent to Email']);
    }
    public function GetDetails(Request $request)
    {
        $user = Auth::user();
        return response()->json(['status'=>1,'message'=>'','data'=>$user]);
    }
    public function Verification(VerficationCode $request)
    {
        $token = $request->code;
        $user = User::whereToken($token)->first();
        if($user){
            $user->whereToken($token)->update(['is_active'=>1]);
            return response()->json(['status'=>1,'message'=>'User Activated successfully']);
        }else{
            return response()->json(['status'=>0,'message'=>"Invalid Token....."]);
        }
    }
    public function ResendCode(CodeResend $request)
    {
        $user = User::whereEmail($request->email)->first();
        if($user)
        {   
            $code = random_int(100000, 999999);
            $user->whereEmail($user->email)->update(['token'=>$code]);
            Mail::to($user)->send(new ResendCode);
            return response()->json(['status'=>1,'message'=>"Code Resent Succesfully"]);
        }else{
            return response()->json(['status'=>0,'message'=>"User not exist"]);
        }
    }
    public function CheckEmail(CheckEmail $request)
    {
        $user = User::whereEmail($request->email)->first();
        if($user)
        {
            $code = random_int(100000, 999999);
            $user->whereEmail($user->email)->update(['token'=>$code]);
            Mail::to($user)->send(new SendCodeEmail);
            return response()->json(['status'=>1,'message'=>"Verification Code Sent To Email"]);
            
        }else{
            return response()->json(['status'=>0,'message'=>"User does not exist.."]);
        }
    }
    public function CheckCode(CheckCode $request)
    {
        $user = User::whereEmail($request->email)->whereToken($request->code)->first();
        if($user){
             return response()->json(['status'=>1,'message'=>"User exist"]);
        }else{
            return response()->json(['status'=>0,'message'=>"User does not exist.."]);
        }
    }
    public function ForgetPassword(PasswordForget $request)
    {
        $user = User::whereEmail($request->email)->first();
        if($user)
        {
            $password = $request->password;
            $conpass = $request->password_confirmation;
            $user->whereEmail($request->email)->update(['password'=>Hash::make($request->password)]);
            Mail::to($user)->send(new ForgetPassword);
            return response()->json(['status'=>1,'message'=>"Password Updated successfully"]);
            
        }else{
            return response()->json(['status'=>0,'message'=>"User does not exist.."]);
        }
    }
    public function ProfileUpdate(ProfileUpdate $request)
    {
        $user = User::find($request->userid);
        if($user){
            $user->update([
                'name' => $request->name,
                'email' => $request->email,
                'phone'=>$request->phone,
            
            ]);
        }else{
            return response()->json(['status'=>0,'message'=>"User Not Found"]);
        }
        return response()->json(['status'=>1,'message'=>"Profile Updated Successfully"]);
    } 
    public function ChangePassword(ChangePassword $request)
    {
       User::whereEmail($request->email)->update(['password'=> Hash::make($request->password)]);
        return response()->json(['status'=>1,'message'=>"Password Updated Successfully"]);
    }
    
}
