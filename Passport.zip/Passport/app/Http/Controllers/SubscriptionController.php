<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubscriptionController extends Controller
{
    public function SuccessPage()
    {
        return view('success');
    }
    public function Checkout(Request $request)
    {
        //dd($request->all());
        // Set your secret key. Remember to switch to your live secret key in production.
        // See your keys here: https://dashboard.stripe.com/apikeys
            \Stripe\Stripe::setApiKey('sk_test_51JNxPjSDmueRSByiyBckRFfkXidQ0N6PORjROO4rHPgZBTMWjSSBLl5GZuDzNsJVfPdJufzFPmkX9gPX3257uUaF00D7mkycEN');

        // The price ID passed from the front end.
        //   $priceId = $_POST['priceId'];
        $priceId = $request->priceId;

        $session = \Stripe\Checkout\Session::create([
          'success_url' => 'https://127.0.0.1/success?session_id={CHECKOUT_SESSION_ID}',
          'cancel_url' => 'https://127.0.0.1',
          'payment_method_types' => ['card'],
          'mode' => 'subscription',
          'line_items' => [[
            'price' => $priceId,
            // For metered billing, do not pass quantity
            'quantity' => 1,
          ]],
        ]);
        //return redirect()->route($session->url);
        // Redirect to the URL returned on the Checkout Session.
        // With vanilla PHP, you can redirect with:
        //   header("HTTP/1.1 303 See Other");
           header("Location: " . $session->url);
    }
}
