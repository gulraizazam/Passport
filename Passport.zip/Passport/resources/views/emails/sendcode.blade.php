@component('mail::message')
# Welcome

Thank you for registering

@component('mail::button', ['url' => '#'])
{{$user->token}}
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
