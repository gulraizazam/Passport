@component('mail::message')
# Code

Your email verification code is below.

@component('mail::button', ['url' => '#'])
{{$user->token}}
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
