@component('mail::message')
# Congratulations

Your password has been successfully changed.



Thanks,<br>
{{ config('app.name') }}
@endcomponent
