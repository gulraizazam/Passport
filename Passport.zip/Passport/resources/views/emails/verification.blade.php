<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Verification</title>
</head>
<body>
	<p>Your verification code is {{$code}}</p>
</body>
</html>