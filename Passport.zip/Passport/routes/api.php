<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



Route::post('login','API\PassportController@Login');
Route::post('register','API\PassportController@Register');
Route::post('verification','API\PassportController@Verification');
Route::post('code/resend','API\PassportController@ResendCode');
Route::post('check/email','API\PassportController@CheckEmail');
Route::post('check/code','API\PassportController@CheckCode');
Route::post('forgetpassword','API\PassportController@ForgetPassword');

Route::group(['middleware' => 'auth:api'], function() {
    Route::post('details','API\PassportController@GetDetails');
    Route::post('changepassword','API\PassportController@ChangePassword');
    Route::post('profile/update','API\PassportController@ProfileUpdate');
    Route::post('user/post','API\PostController@AddPost');
});